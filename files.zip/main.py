import wfdb
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
from preprocessing import PreprocessingBlock
from bss import IcaBlock, PcaBlock
from qrs import PrimaryQrsBlock, SecondaryQrsBlock
from compare import CompareQrsBlock4Channels


record = wfdb.rdrecord("samples/b01")
signals, fs, adc_data = record.p_signal, record.fs, (record.adc_gain[0], record.adc_zero[0])
ts = np.linspace(0, len(signals)/fs, len(signals))

# preprocessing
block_0 = PreprocessingBlock()
prep_sig, prep_ts = block_0.forward(signals, ts)

# primary gqrs
block_2 = PrimaryQrsBlock(100, *adc_data)
qrs1_sig, qrs1_ts = block_2.forward(prep_sig, prep_ts)

plt.figure(1)
i = 1
for qrs, channel in zip(qrs1_sig.T, prep_sig.T):
    qrs_indexes = np.where(qrs)
    qrs_ts = prep_ts[qrs_indexes]    

    plt.subplot(prep_sig.shape[-1],1,i)
    plt.plot(qrs_ts, qrs[qrs_indexes], 'rx')
    plt.plot(prep_ts, channel)    
    plt.xlim((38,42))
    i+=1



def create_epochs(start, window, sig):
    # setting up where the epoch starts and ends
    epoch_indexes = np.repeat(start,2)
    epoch_indexes[1::2] += window 

    # splitting at the specified places and selecting the desired parts
    return np.vstack(np.split(thissig, epoch_indexes)[1::2]).T, epoch_indexes

thissig = prep_sig[:,0]
thisqrs = qrs1_sig[:,0]

zs = []
stored_qrs_epochs = []
stored_epoch_indexes = []
for thissig, thisqrs in zip(prep_sig.T, qrs1_sig.T):

    ### qrs epoch decomposition ###
    qrs_indexes = np.where(thisqrs != 0)[0]
    qrs_window = int(100e-3 * fs)  # sampling points inside a 100ms window
    qrs_epochs, epoch_indexes = create_epochs(qrs_indexes, qrs_window, thissig)
    zs.append(qrs_epochs)
    stored_qrs_epochs.append(qrs_epochs)
    stored_epoch_indexes.append(epoch_indexes)
    #################################

z = np.hstack(zs)

### PCA 2 ###
block_3 = PcaBlock()
pcr, _ = block_3.forward(z.T, None)
####

new_sig = np.copy(prep_sig)

i = 0
for qrs_epochs, epoch_indexes in zip(stored_qrs_epochs, stored_epoch_indexes):
    for s,e in zip(epoch_indexes[::2], epoch_indexes[1::2]):
        idx = np.arange(s,e)
        qrs_complex = new_sig[idx,i]
        new_sig[idx,i] = qrs_complex - pcr.predict(qrs_complex.reshape(1,-1))
    i += 1

block_4 = PrimaryQrsBlock(50,3,0)
qrs2_sig, qrs2_ts = block_4.forward(new_sig, prep_ts)

plt.figure(2)
plt.subplot(3,1,1)
plt.plot(prep_ts, prep_sig[:,0])
plt.xlim((38,42))
plt.title("Original Channel")

plt.subplot(3,1,2)
plt.plot(prep_ts, new_sig[:,0])
#plt.plot(qrs2_ts, qrs2_sig[:,0], "rx")
plt.xlim((38,42))
plt.title("Removed mECG")

plt.subplot(3,1,3)
plt.plot(prep_ts, prep_sig[:,0])
plt.plot(prep_ts, new_sig[:,0])
plt.xlim((38,42))
plt.title("Overlap")

plt.tight_layout()

plt.show()