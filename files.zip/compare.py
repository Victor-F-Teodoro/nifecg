from generic import Block
from numpy import correlate, argmax, array

class CompareQrsBlock4Channels(Block):
	"""
	Block for comparing the likeness of the channels to the 
	ICA outputs, this is an important step for extracting the mother
	ECG 
	"""

	def forward(self, sig, ts):
		"""
		method for treating the signal

		Parameters:
			sig : ndarray
				signal data
			ts : ndarray
				signal timestamps
		Returns:
			sig : ndarray
				treated signal
			ts : ndarray
				treated signal timestamps
		"""

		primary, secondary, primary_qrs, secondary_qrs = sig

		corr_matrix = array([ [ max(correlate(x,y)) for x in secondary_qrs] for y in primary_qrs ])
		best = argmax(corr_matrix)

		m,n = corr_matrix.shape
		i = best//m

		return [primary[:,i], primary_qrs[i]], ts